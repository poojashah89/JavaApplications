package com.intranet.folder.service;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.intranet.calendar.service.CalendarBean;
import com.intranet.calendar.service.CalendarService;

import java.util.List;
import java.util.Map;

/**
 * Created by sindhya on 4/9/17.
 */

@RestController
public class FolderServiceController {

    private String message = "Hello World";

    @RequestMapping("/")
    public String welcome(Map<String, Object> model) {
        model.put("message", this.message);
        return "welcome";
    }

    @RequestMapping("/getCalendar")
    public String getCalendar(Map<String, Object> model) {
        model.put("message", this.message);
        CalendarService events = new CalendarService();
        
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        String json;
        try{
        	List<CalendarBean> caleandarData = events.getEvents();
        	json = ow.writeValueAsString(caleandarData);
        } catch(Exception ex){
        	return "Error occured";
        }
        
        return json;
    }
}
